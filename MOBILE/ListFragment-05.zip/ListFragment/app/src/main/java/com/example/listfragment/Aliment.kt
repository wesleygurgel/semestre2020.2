package com.example.listfragment

class Aliment(var nome: String, var preco: Double) {


    override fun toString(): String {
        return this.nome
    }


}