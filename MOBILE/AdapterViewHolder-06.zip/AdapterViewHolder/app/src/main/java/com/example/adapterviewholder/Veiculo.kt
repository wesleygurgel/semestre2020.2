package com.example.adapterviewholder

data class Veiculo (
    var modelo: String,
    var ano: Int,
    var fabricante: Int,
    var gasolina: Boolean,
    var etanol: Boolean
)