package com.example.recyclerview

data class Message (var title: String, var text: String)